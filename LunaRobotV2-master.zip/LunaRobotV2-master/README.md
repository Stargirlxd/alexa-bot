

<p align="center">
  <img src="https://telegra.ph/file/e052e680ba705b7ed7be5.jpg">
<h1 align="center"><b> Luna Robot </b></h1>
</p>
<h4 align="center">A Powerful, Smart And Simple Group Manager <br> ... Written with AioGram , Pyrogram and Telethon...</h4>
<p align='center'>
  <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-1f425f.svg?style=flat-square&logo=python&color=blue" /> </a>
  <a href="https://github.com/zeinzo/LunaRobotV2/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square" /> </a>
  <a href="https://t.me/lunaupdate"><img src="https://img.shields.io/badge/Join-Luna%20Updates-red.svg?logo=Telegram"></a>
  <a href="https://t.me/lunasupportgroup"><img src="https://img.shields.io/badge/Join-Luna%20Support-blue.svg?logo=telegram"></a>
  <a href="https://t.me/tdrki_1"><img src="https://img.shields.io/badge/Developer-Luna%20Robot-blue.svg?logo=telegram"></a>


### Available on Telegram as [@lunatapibot](https://t.me/lunatapibot)

### DEPLOY TO HEROKU⤵️
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/zeinzo/LunaRobotV2"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

```
This Bot is Created by ZeinzoProject, If your kanging this without fork at least give a credit to get a smile of my hard work. 
- LunaRobot
- Innexia
```

## Credits Luna Robot💫

- [Zeinzo](https://github/zeinzo) ``Dev``
- [RIZ-EX](https://github.com/riz-ex) ``Dev``
- [Arya](https://github.com/aryazakaria01) ``Contributor``
- [Original Repo](https://github.com/TeamDeeCode/innexia) ``Innexia``
